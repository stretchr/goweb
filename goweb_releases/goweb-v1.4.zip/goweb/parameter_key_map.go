package goweb

// Holds parameter keys and their respective positions in the path
type ParameterKeyMap map[string]int
