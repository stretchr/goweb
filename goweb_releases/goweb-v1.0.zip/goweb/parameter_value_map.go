package goweb

// Holds parameter keys and actual values
type ParameterValueMap map[string]string