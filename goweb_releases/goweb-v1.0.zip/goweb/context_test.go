package goweb

import (
	"testing"
	"http"
)

func MakeTestContext() *Context {
	var request *http.Request = new(http.Request)
	var responseWriter http.ResponseWriter
	var pathParams ParameterValueMap = make(ParameterValueMap)
	
	return makeContext(request, responseWriter, pathParams)
}

func TestMakeContext(t *testing.T) {
	
	var request *http.Request = new(http.Request)
	var responseWriter http.ResponseWriter
	var pathParams ParameterValueMap = make(ParameterValueMap)
	
	context := makeContext(request, responseWriter, pathParams)
	
	if context.Request != request {
		t.Errorf("context.Request incorrect")
	}
	if context.ResponseWriter != responseWriter {
		t.Errorf("context.ResponseWriter incorrect")
	}
	if context.PathParams != pathParams {
		t.Errorf("context.PathParams incorrect")
	}
	
}

/*

	Quick method checking helpers

*/

func AssertNotGet(c *Context, t *testing.T) {
	if c.IsGet() {
		t.Errorf("IsGet should be false for '%s' method.", c.Request.Method)
	}
}
func AssertNotPost(c *Context, t *testing.T) {
	if c.IsPost() {
		t.Errorf("IsPost should be false for '%s' method.", c.Request.Method)
	}
}
func AssertNotPut(c *Context, t *testing.T) {
	if c.IsPut() {
		t.Errorf("IsPut should be false for '%s' method.", c.Request.Method)
	}
}
func AssertNotDelete(c *Context, t *testing.T) {
	if c.IsDelete() {
		t.Errorf("IsDelete should be false for '%s' method.", c.Request.Method)
	}
}
func AssertGet(c *Context, t *testing.T) {
	if !c.IsGet() {
		t.Errorf("IsGet should be true for '%s' method.", c.Request.Method)
	}
}
func AssertPost(c *Context, t *testing.T) {
	if !c.IsPost() {
		t.Errorf("IsPost should be true for '%s' method.", c.Request.Method)
	}
}
func AssertPut(c *Context, t *testing.T) {
	if !c.IsPut() {
		t.Errorf("IsPut should be true for '%s' method.", c.Request.Method)
	}
}
func AssertDelete(c *Context, t *testing.T) {
	if !c.IsDelete() {
		t.Errorf("IsDelete should be true for '%s' method.", c.Request.Method)
	}
}

func TestIsGet(t *testing.T) {
	
	context := MakeTestContext()
	
	// set the request method
	context.Request.Method = GET_HTTP_METHOD
	
	AssertGet(context, t)
	AssertNotPost(context, t)
	AssertNotPut(context, t)
	AssertNotDelete(context, t)
	
}
func TestIsPost(t *testing.T) {
	
	context := MakeTestContext()
	
	// set the request method
	context.Request.Method = POST_HTTP_METHOD
	
	AssertNotGet(context, t)
	AssertPost(context, t)
	AssertNotPut(context, t)
	AssertNotDelete(context, t)
	
}
func TestIsPut(t *testing.T) {
	
	context := MakeTestContext()
	
	// set the request method
	context.Request.Method = PUT_HTTP_METHOD
	
	AssertNotGet(context, t)
	AssertNotPost(context, t)
	AssertPut(context, t)
	AssertNotDelete(context, t)
	
}
func TestIsDelete(t *testing.T) {
	
	context := MakeTestContext()
	
	// set the request method
	context.Request.Method = DELETE_HTTP_METHOD
	
	AssertNotGet(context, t)
	AssertNotPost(context, t)
	AssertNotPut(context, t)
	AssertDelete(context, t)
	
}