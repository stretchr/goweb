package goweb

import "strings"

/*
	Path parsing
*/

// Tests whether a path segment is dynamic or not
func isDynamicSegment(segment string) bool {
	return strings.HasPrefix(segment, "{") && strings.HasSuffix(segment, "}")
}

// Splits a path into its segments
func getPathSegments(path string) []string {
	return strings.Split(strings.Trim(path, "/"), "/", -1)
}

// Generates a parameter value map from the specified parameter key map and path
func getParameterValueMap(keys ParameterKeyMap, path string) ParameterValueMap {

	var paramValues ParameterValueMap = make(ParameterValueMap)

	var segments []string = getPathSegments(path)
	for k, index := range keys {
    paramValues[k] = segments[index]
  }

	return paramValues

}