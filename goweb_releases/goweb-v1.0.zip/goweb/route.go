package goweb

import (
	"regexp"
	"strings"
)


/*
	Route
*/

// Represents a single route mapping
type Route struct {
	pattern string
	parameterKeys ParameterKeyMap
	Path string
	Controller Controller
	MatcherFuncs []RouteMatcherFunc
}

// Makes a new route from the given path
func makeRouteFromPath(path string) *Route {
	
	// get the path segments
	segments := getPathSegments(path)
	regexSegments := make([]string, len(segments))
	
	// prepare the parameter key map
	var paramKeys ParameterKeyMap = make(ParameterKeyMap)
	
	// pull out any dynamic segments
	for index, _ := range segments {
		if isDynamicSegment(segments[index]) {
			paramKeys[strings.Trim(segments[index], "{}")] = index
			regexSegments[index] = ROUTE_REGEX_PLACEHOLDER
		} else {
			regexSegments[index] = segments[index]
		}
	}
	
	patternString := "/" + strings.Join(regexSegments, "/")
	
	// return a new route
	var route *Route = new(Route)
	route.pattern = patternString
	route.parameterKeys = paramKeys
	route.Path = path
	route.Controller = nil
	return route
	
}

// Gets the parameter values for the route from the specified path
func (route *Route) getParameterValueMap(path string) ParameterValueMap {
	return getParameterValueMap(route.parameterKeys, path)
}

// Checks whether a path matches a route or not
func (route *Route) DoesMatchPath(path string) bool {
	
	match, error := regexp.MatchString(route.pattern, path)

	if error == nil {
		return match
	}

	// error :-(
	return false

}

// Checks whether the context for this request matches the route
func (route *Route) DoesMatchContext(c *Context) bool {
	
	// by default, we match
	var match bool = true
	
	if len(route.MatcherFuncs) > 0 {
		
		// there are some matcher functions, so don't automatically
		// match by default - let the matchers decide
		match = false
		
		// loop through the matcher functions
		for _, f := range route.MatcherFuncs {
			
			// modify 'match' based on the result of the matcher function
			switch f(c) {
			case NoMatch: match = false
			case Match: match = true
			}
			
		}
		
	}
	
	// return the result
	return match
	
}

