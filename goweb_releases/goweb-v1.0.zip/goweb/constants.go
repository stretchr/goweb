package goweb

/*
	Constants
*/

// Regex placeholder pattern
var ROUTE_REGEX_PLACEHOLDER string  = "(.*)"

// HTTP Methods
const GET_HTTP_METHOD string = "GET"
const POST_HTTP_METHOD string = "POST"
const PUT_HTTP_METHOD string = "PUT"
const DELETE_HTTP_METHOD string = "DELETE"

/*
	HTTP Status codes
*/
const HTTP_STATUS_INTERNAL_SERVER_ERROR int = 500

/*
	Error messages
*/
const ERR_STANDARD_PREFIX string = "Oops, something went wrong: "
const ERR_NO_CONTROLLER string = "Routes must have a valid Controller"
const ERR_NO_MATCHING_ROUTE string = "No route found for that path"