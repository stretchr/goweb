package goweb

import "testing"

func TestGetPathSegments(t *testing.T) {
	
	var segments []string = getPathSegments(routePath)
	
	if (segments[0] != "people") {
		t.Errorf("'%s' expected to be 'people'", segments[0])
	}
	if (segments[1] != "{id}") {
		t.Errorf("'%s' expected to be '{id}'", segments[1])
	}
	if (segments[2] != "groups") {
		t.Errorf("'%s' expected to be 'groups'", segments[2])
	}
	if (segments[3] != "{group_id}") {
		t.Errorf("'%s' expected to be '{group_id}'", segments[3])
	}
	
}

func TestIsDynamicSegment(t *testing.T) {
	
	if (isDynamicSegment("no")) {
		t.Errorf("'no' is not a dynamic segment")
	}
	if (isDynamicSegment("{not-quite")) {
		t.Errorf("'{not-quite' is not a dynamic segment")
	}
	if (isDynamicSegment("not-me-either}")) {
		t.Errorf("'not-me-either}' is not a dynamic segment")
	}
	
	if (!isDynamicSegment("{i-am}")) {
		t.Errorf("'i-am' is a dynamic segment")
	}
	
}

func TestGetParameterValueMapFromPath(t *testing.T) {
	
	var route *Route = makeRouteFromPath(routePath)
	var paramKeys ParameterKeyMap = route.parameterKeys
	var paramValues ParameterValueMap = getParameterValueMap(paramKeys, "/people/123/groups/456")
	
	if (len(paramValues) != 2) {
		t.Errorf("paramValues should have 2 items")
	}
	if (paramValues["id"] != "123") {
		t.Errorf("paramKeys['id'] expected to be '123', but was %s", paramValues["id"])
	}
	if (paramValues["group_id"] != "456") {
		t.Errorf("paramKeys['group_id'] expected to be '456', but was %s", paramValues["group_id"])
	}
	
}