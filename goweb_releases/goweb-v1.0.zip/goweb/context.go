package goweb

import "http"

// Object holding details about the request and responses
type Context struct {
	
	// The underlying http.Request for this context
	Request *http.Request
	
	// The underlying http.ResponseWriter for this context
	ResponseWriter http.ResponseWriter
	
	// A ParameterValueMap containing path parameters
	PathParams ParameterValueMap
	
}

// Helper function to make a new Context object
// with the specified http.Request, http.ResponseWriter and ParameterValueMap
func makeContext(request *http.Request, responseWriter http.ResponseWriter, pathParams ParameterValueMap) *Context {
	var context *Context = new(Context)
	context.Request = request
	context.ResponseWriter = responseWriter
	context.PathParams = pathParams
	return context
}

/*
	HTTP Method helper functions
*/

// Checks whether the HTTP method is GET or not
func (c *Context) IsGet() bool {
	return c.Request.Method == GET_HTTP_METHOD
}

// Checks whether the HTTP method is POST or not
func (c *Context) IsPost() bool {
	return c.Request.Method == POST_HTTP_METHOD
}

// Checks whether the HTTP method is PUT or not
func (c *Context) IsPut() bool {
	return c.Request.Method == PUT_HTTP_METHOD
}

// Checks whether the HTTP method is DELETE or not
func (c *Context) IsDelete() bool {
	return c.Request.Method == DELETE_HTTP_METHOD
}
